Phono-Control Installer
-----------------------

To build the binary:
  $ make

To install using Packages.app:
  1. Open 'phono-control.pkgproj' in Packages.app
  2. Click Build

The binary will be installed to /usr/local/bin/phono-control.

To uninstall:
  $ sudo phono-control-uninstall.sh
