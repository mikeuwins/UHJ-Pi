#!/bin/bash
echo "Uninstalling phono-control..."
rm -f /usr/local/bin/phono-control
rm -f /usr/local/bin/phono-control-uninstall.sh
echo "Done."
